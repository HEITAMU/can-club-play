// Generated native WeChat Mini Game entry; no HTML or web-view.
if(!Array.prototype.at)Object.defineProperty(Array.prototype,'at',{value:function(i){i=Math.trunc(i)||0;return this[i<0?this.length+i:i];}});
if(!Object.fromEntries)Object.fromEntries=function(entries){var result={};for(var pair of entries)result[pair[0]]=pair[1];return result;};
require('./runtime.js').boot(wx,require('./asset-manifest.json'));
